# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 11:09:49 2021

@author: jimena
"""

class Persona:
    def __init__(self,nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def mostrar(self):
        pass

class Empresa:

    def __init__(self,nombre):
        self.nombre = nombre
        
class Cliente(Persona):
    def __init__(self,nombre, edad,nombre_empresa,telefono_contato,empresa):
        super().__init__(nombre, edad)
        self.telefono_contato = telefono_contato
        self.nombre_empresa = nombre_empresa
        self.empresa = Empresa(nombre)

    def mostrar(self):
        pass

class Empleado(Persona):
    def __init__(self,nombre, edad,sueldo_bruto,empresa):
        super().__init__(nombre, edad)  
        self.sueldo_bruto = sueldo_bruto
        self.empresa = Empresa(nombre)

    def mostar(self):
        pass

    def Calcular_salario_neto(self):
        pass

class Directivo(Empleado):
    def __init__(self,nombre,edad, sueldo_bruto, categoria,empresa):
        super().__init__(nombre, edad,sueldo_bruto,empresa)
        self.sueldo_bruto = sueldo_bruto
        self.categoria = categoria

    def mostrar(self):
        pass
            