from calculadora import Calculator

class CalculadoraDosNumeros(Calculator):

    def __init__(self, num1, num2):
        self.__num1 = num1
        self.__num2  = num2

    # Getters y setters
    @property
    def num1(self): 
        return self.__num1 
       
    @num1.setter 
    def num1(self, num1): 
        self.__num1 = num1 

    @property
    def num2(self): 
        return self.__num2 
       
    @number2.setter 
    def num2(self, num2): 
        self.__num2 = num2 

    # Funciones operaciones
    def addition(self):
        return self.num1 + self.num2
    
    def subtracrtion(self):
        return self.num1 - self.num2
    
    def multiplication(self): 
        return self.num1 * self.num2
    
    def division(self):
        return self.num2 / self.num1

    def modulo(self):
        return self.num % self.num1