from calculadora import Calculator

class CalculadoraTresNumeros(Calculator):

    def __init__(self, num1, num2, num3):
        self.__num1 = num1
        self.__num2 = num2
        self.__num3 = num3

    # Getters y setters
    @property
    def number1(self): 
        return self.__num1 
       
    @number1.setter 
    def num1(self, num1): 
        self.__num1 = num1 

    @property
    def num2(self): 
        return self.__num2 
       
    @number2.setter 
    def num2(self, num2): 
        self.__num2 = num2 

    @property
    def num3(self): 
        return self.__num3 
       
    @number3.setter 
    def num3(self, num3): 
        self.__num3 = num3 


    # Funciones operaciones
    def addition(self):
        return self.num1 + self.num2 + self.__num3
    
    def subtracrtion(self):
        return self.num1 - self.num2 - self.__num3
    
    def multiplication(self): 
        return self.num1 * self.num2 * self.__num3 