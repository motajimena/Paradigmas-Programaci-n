# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 09:31:31 2021

@author: jimena
"""

def Suma(x, y):
    return x + y

def Resta(x, y):
    return x - y

def Multiplicar(x, y):
    return x * y

def Dividir(x, y):
    return x / y

#Menú
print("Operación a Realizar")
print("1. Suma")
print("2. Resta")
print("3. Multiplicar")
print("4. Dividir")

#Operación a realizar
choice = input("Elige una opción: ")
num1 = int(input("Ingresa un número : "))
num2 = int(input("Ingresa un segundo número: "))
if choice == '1':
    print("La suma es: ", Suma(num1, num2))
elif choice == '2':
    print("La resta es: ", Resta(num1,num2))
elif choice == '3':
    print("La multiplicación es: ", Multiplicar(num1,num2))
elif choice == '4':
    print("La división es: ", Dividir(num1,num2))
else:
    print("Opción Invalida")