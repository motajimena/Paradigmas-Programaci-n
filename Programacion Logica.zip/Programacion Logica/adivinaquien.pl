start :-
nl,
write('PARA ADIVINAR EL ANIMAL EN EL QUE ESTAS PENSANDO, '),
nl,
write('RESPONDE A LAS SIGUIENTES PREGUNTAS'),
nl,
nl,

sera(Animal),
nl,
nl,
write('****************************************'),
nl,
write('Creo que el animal es '),
write(Animal),
nl,
write('****************************************'),
nl,
nl,

write('�He acertado? (s/n) '),
read(Respuesta),
nl,
( (Respuesta == s)
->
borrar,
seguir_jugando ;
write('�Qu� animal es? '),
read(Respuesta1),
nl,
write('Dime una pregunta para '),
 write(Respuesta1),
write(' que lo diferencie de '),
 write(Animal),
 write(': '),
read(Respuesta2),
 nl,
 nl,
asserta( (sera(Respuesta1) :- Animal, verificar(Respuesta2)) ) ,
borrar,
seguir_jugando).

sera(rana) :- rana, !.
sera(salamandra) :- salamandra, !.
sera(serpiente) :- serpiente, !.
sera(tortuga) :- tortuga, !.
sera(cocodrilo) :- cocodrilo, !.
sera(jirafa) :- jirafa, !.
sera(conejo) :- conejo, !.
sera(hombre) :- hombre, !.
sera(oso) :- oso, !.
sera(tigre) :- tigre, !.
sera(leon) :- leon, !.
sera(aguila) :- aguila, !.
sera(pato) :- pato, !.
sera(gallina) :- gallina, !.
sera(avestruz) :- avestruz, !.
sera(pinguino) :- pinguino, !.
sera(carpa) :- carpa, !.
sera(pez_espada):- pez_espada.

rana :- sangre_fria,
 anfibio,
 verificar(salta).
salamandra :- sangre_fria,
 anfibio.

serpiente :- sangre_fria,
verificar(se_arrastra).
tortuga :- sangre_fria,
 verificar(tiene_caparazon).
cocodrilo :- sangre_fria.

jirafa :- mamifero,
 herbivoro,
verificar(tiene_cuello_largo).
conejo :- mamifero,
 herbivoro.
hombre :- mamifero,
 omnivoro,
 verificar(razona).
oso :- mamifero,
 omnivoro.
tigre :- mamifero,
 verificar(tiene_rayas).
leon :- mamifero.

aguila :- ave,
voladora,
 verificar(es_ave_rapaz).
pato :- ave,
 voladora.
gallina :- ave,
 verificar(es_domestico).
avestruz :- ave,
 verificar(corre_veloz).
pinguino :- ave.

carpa :- verificar(vive_rio).
pez_espada.

sangre_fria :- verificar(tiene_sangre_fria).
anfibio :- verificar(vive_tierra_y_agua).
mamifero :- verificar(tiene_pelo).
herbivoro :- verificar(es_herbivoro).
omnivoro :- verificar(es_omnivoro).
ave :- verificar(tiene_alas).
voladora :- verificar(vuela).

verificar(S) :-
(cumple(S)
->
true ;
(no_cumple(S)
->
fail ;
preguntar(S))).
preguntar(Pregunta) :-
write('�Tiene el animal la siguiente caracter�stica: '),
write(Pregunta),
write('? (s/n) '),
 read(Respuesta),
nl,

( (Respuesta == s)
->
assert(cumple(Pregunta)) ;
assert(no_cumple(Pregunta)), fail).
seguir_jugando :-
write('�Quieres seguir jugando? '),
read(Respuesta3),
( (Respuesta3 == s)
->
start ;
nl,
nl,
write('ESPERO QUE HAYAS DISFRUTADO JUGANDO CONMIGO'),
nl,
nl,
write('ADIOS'),
nl).

:- dynamic cumple/1,no_cumple/1,sera/1,verificar/1.

borrar :- retract(cumple(_)),fail.
borrar :- retract(no_cumple(_)),fail.
borrar.

