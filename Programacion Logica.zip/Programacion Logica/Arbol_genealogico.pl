mujer(rafaela).
mujer(arminda).
mujer(susana).

hombre(jose).
hombre(roberto).
hombre(jorge).
hombre(rodrigo).
hombre(daniel).

padres(rafaela,jorge).
padres(jose,jorge).
padres(arminda,susana).
padres(roberto,susana).

padres(susana,rodrigo).
padres(jorge,rodrigo).
padres(susana,daniel).
padres(jorge,daniel).

esposos(jose,rafaela).
esposos(roberto,arminda).
esposos(jorge,susana).

padre(X,Y) :- hombre(X) , padres(X,Y).
madre(X,Y) :- mujer(X), padres(X,Y).
hermanos(X,Y) :- padres(Z,X), padres(Z,Y).
hermano(X,Y) :- hombre(X), hermanos(X,Y).
esposo(X,Y) :- hombre(X), esposos(X,Y).
esposa(Y,X) :- mujer(Y), esposos(X,Y).
hijo(X,Y) :- hombre(X), padres(Y,X).

