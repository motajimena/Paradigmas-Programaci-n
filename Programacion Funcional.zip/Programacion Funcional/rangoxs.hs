rango :: [Int] -> [Int]
rango xs = [minimum xs, maximum xs]