mayorRectangulo :: (Int,Int) -> (Int,Int) -> (Int,Int)
mayorRectangulo (w,x) (y,z) | w * x >= y * z = (w,x)
mayorRectangulo (w,x) (y,z) | otherwise = (y,z)