areaCoronaCircular :: Double -> Double -> Double
areaCoronaCircular x y = 3.1416 * (y*y - x*x)
