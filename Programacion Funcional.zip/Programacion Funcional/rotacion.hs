rota1 :: Int -> Int -> Int -> Int -> Int -> Int -> Int -> Int
rota1 xs = tail xs ++ [head xs]
