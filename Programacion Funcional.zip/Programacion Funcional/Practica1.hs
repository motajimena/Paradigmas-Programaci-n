sumaMonedas :: Int -> Int -> Int -> Int -> Int -> Int 
sumaMonedas a b c d e = a + b*2 + c*5 + d*10 + e*20

main = do
print(sumaMonedas 1 1 1 1 1)