rota1 :: [a] -> [a]
rota1 (x:xs) = xs ++ [x]