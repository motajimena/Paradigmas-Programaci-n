maxTres :: Int -> Int -> Int -> Int
maxTres x y z = max x (max y z)

main = do 
print(maxTres 3 9 6)
