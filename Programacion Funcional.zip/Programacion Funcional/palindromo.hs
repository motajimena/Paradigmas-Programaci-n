palindromo :: [Int] -> Bool
palindromo xs = xs == reverse xs