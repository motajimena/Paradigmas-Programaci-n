interior :: [Int]-> [Int]
interior xs = tail (init xs)