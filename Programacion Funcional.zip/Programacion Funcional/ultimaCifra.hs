ultimaCifra :: Integral a -> a -> a
ultimaCifra num = mod num 10