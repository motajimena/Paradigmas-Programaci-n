volumenEsfera :: Double -> Double
volumenEsfera x = (4 * 3.1416 * (x*x*x)) / 3

main = do
print (volumenEsfera 15)

