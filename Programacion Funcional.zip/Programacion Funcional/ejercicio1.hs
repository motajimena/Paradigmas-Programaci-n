cuadrante :: (Int,Int) -> Int
cuadrante (x,y) | x > 0 && y > 0 = 1
cuadrante (x,y) | x < 0 && y > 0 = 2
cuadrante (x,y) | x < 0 && y < 0 = 3
cuadrante (x,y) | x > 0 && y < 0 = 4